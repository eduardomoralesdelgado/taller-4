
<template>
  <div class="home">
    <custom-component1 :data="motos[0]" />
    <custom-component2 :data="motos[1]" />
    <custom-component3 :data="motos[2]" />
    <custom-component4 :data="motos[3]" />
  </div>
</template>

<script>
import customComponent1 from "@/components/CustomComponent1.vue";
import customComponent2 from "@/components/CustomComponent2.vue";
import customComponent3 from "@/components/CustomComponent3.vue";
import customComponent4 from "@/components/CustomComponent4.vue";

export default {
  components: {
    customComponent1,
    customComponent2,
    customComponent3,
    customComponent4,
  },
  data() {
    return {
      motos: [],
    };
  },
  mounted() {
    fetch("/motos.json")
      .then((response) => response.json())
      .then((data) => {
        
        this.motos = data.motos.map((moto) => {
          return {
            ...moto,
            modelo: "Moto " + (Math.floor(Math.random() * 100) + 1),
            descripcion: "Descripción personalizada",
            
          };
        });
      });
  },
};
</script>

<style scoped>

.home {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
</style>
